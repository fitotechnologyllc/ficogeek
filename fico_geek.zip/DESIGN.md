# Design System Strategy: The Sovereign Ledger

## 1. Overview & Creative North Star
The design system for this platform is governed by a Creative North Star we call **"The Sovereign Ledger."** 

In the intersection of fintech and legal-tech, users are often navigating high-stakes, stressful data. Most platforms respond with "utility-only" grids that feel cold and bureaucratic. "The Sovereign Ledger" rejects this. It combines the high-end editorial clarity of a premium financial journal with the tactile, layered depth of modern productivity software. 

We break the "SaaS template" look through **intentional asymmetry** and **tonal layering**. We prioritize large, breathing margins and high-contrast typography scales that command authority. The experience shouldn't feel like a database; it should feel like a private, secure, and expertly curated workspace where every document and data point has a place of honor.

---

## 2. Colors: Tonal Depth vs. Structural Lines
This system utilizes a sophisticated palette that moves away from traditional "box-and-line" UI. 

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section off the interface. Standard borders create visual noise and make an interface feel "cheap" and rigid. Instead, define boundaries solely through **Background Color Shifts**. 
*   *Example:* A `surface-container-low` (#f1f3ff) card sitting on a `surface` (#f9f9ff) background creates a clean, sophisticated edge without a single line.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, physical layers.
*   **Base:** `surface` (#f9f9ff) - The canvas.
*   **Sectioning:** `surface-container-low` (#f1f3ff) - Subtle groupings.
*   **Interaction/Cards:** `surface-container-lowest` (#ffffff) - High-priority focal points.
*   **Depth:** Use `surface-container-highest` (#dce2f7) for sidebars or "drawers" to create a sense of architectural permanence.

### The "Glass & Gradient" Rule
To elevate the "Modern Tech" feel, use **Glassmorphism** for floating elements (like headers or navigation bars). 
*   **Spec:** Apply `surface` with 80% opacity and a `20px` backdrop-blur. 
*   **Signature Textures:** For main CTAs and "Hero" cards, use a subtle linear gradient from `primary` (#000615) to `primary_container` (#0b1f3a) at a 135-degree angle. This adds a "soul" to the professional polish that flat navy cannot achieve.

---

## 3. Typography: The Editorial Voice
We use **Inter** not as a system font, but as a deliberate typographic choice for legibility and modernist authority.

*   **Display & Headline (The Command):** `display-lg` to `headline-sm` should be used with a slightly tighter letter-spacing (-0.02em) and `Font-Weight: 700`. This creates a dense, authoritative "block" of text that acts as a visual anchor.
*   **Title (The Navigator):** `title-lg` (1.375rem) is your primary tool for card headings. It should feel balanced and inviting.
*   **Body (The Record):** Use `body-md` (0.875rem) for most data. It provides enough density to show complex credit information without overwhelming the eye.
*   **Label (The Meta):** `label-sm` (0.6875rem) in `Font-Weight: 600` and `Uppercase` should be used for metadata and status indicators, providing an "archival" feel.

---

## 4. Elevation & Depth: The Layering Principle
We convey hierarchy through **Tonal Layering** rather than shadows or strokes.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift. This mimics fine paper stock layered on a desk.
*   **Ambient Shadows:** For floating modals or dropdowns, shadows must be "Ambient." 
    *   *Values:* `0px 20px 40px rgba(20, 27, 43, 0.06)`. 
    *   The shadow is a tinted version of `on_surface`, making it feel like light is passing through the element rather than a muddy grey drop-shadow.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility (e.g., in high-contrast modes), use a "Ghost Border": `outline_variant` at **15% opacity**. Never use 100% opaque borders.

---

## 5. Components: Bespoke Elements

### Primary Action Buttons
*   **Style:** `primary` (#000615) background with `on_primary` text.
*   **Shape:** `md` (0.75rem / 12px) corner radius.
*   **Interaction:** On hover, shift to `secondary` (#005cba) for a vibrant "Electric" feedback.

### Secure File Grids
*   **Rule:** Forbid divider lines between files.
*   **Structure:** Use `surface-container-low` (#f1f3ff) for the grid background and `surface-container-lowest` (#ffffff) for the individual file cards. Use a `1.5rem` (24px) gap between items to let the layout breathe.

### Step-by-Step Wizards (Steppers)
*   **Style:** Use a vertical "Editorial" layout. The active step uses a `tertiary_fixed` (#62fae3) accent bar (4px wide) on the left side, rather than a standard horizontal circle-and-line stepper. This feels more like a legal document checklist.

### Modern Dashboards
*   **Asymmetry:** Avoid perfectly symmetrical 4-column grids. Use a "Golden Ratio" layout: a large 2/3 width section for the main "Ledger" data and a 1/3 width section for "Status Summaries."

### Input Fields
*   **Style:** `surface_container_lowest` background with a `Ghost Border`.
*   **Focus State:** Instead of a thick border, use a 2px outer glow of `secondary` (#005cba) at 30% opacity.

---

## 6. Do's and Don'ts

### Do
*   **Use White Space as a Tool:** Use the `20` (5rem) or `24` (6rem) spacing scale between major sections to emphasize importance.
*   **Stack Surfaces:** Think in 3D. If an element is "inside" another, it should usually be a lighter surface color.
*   **High-Contrast Typography:** Pair a `display-sm` headline with `body-sm` metadata to create a "Premium News" hierarchy.

### Don't
*   **No "Boxy" Buttons:** Avoid 0px or 4px corners; keep to the `md` (12px) or `lg` (16px) scale to maintain the "Modern Tech" softness.
*   **No Pure Black Shadows:** Never use `#000000` for shadows. Use a transparent tint of the primary navy.
*   **No Grid-Lock:** Don't feel forced to align everything to a center axis. A slightly offset "Editorial" left-align often feels more custom and high-end.
*   **No Divider Lines:** If you feel the urge to add a `<hr>` line, try adding `1.5rem` of vertical space instead.